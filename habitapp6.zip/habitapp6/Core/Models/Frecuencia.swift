import Foundation

public enum Frecuencia : String, Codable, CaseIterable, Equatable {
    case diario
    case semanal
}
